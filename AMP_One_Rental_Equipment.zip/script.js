function selectModel(model) {
    document.getElementById('model').value = model;
    document.getElementById('booking').scrollIntoView({ behavior: 'smooth' });
}
function scrollToBooking() {
    document.getElementById('booking').scrollIntoView({ behavior: 'smooth' });
}
function sendWhatsApp() {
    const phone = '60149285514';
    const model = document.getElementById('model').value;
    const pickup = document.getElementById('pickup').value;
    const returnDate = document.getElementById('returnDate').value;
    const name = document.getElementById('name').value;
    const userPhone = document.getElementById('phone').value;
    const note = document.getElementById('note').value;

    const message = `New Booking Request 🎥%0A------------------------%0AModel: ${model}%0APickup: ${pickup}%0AReturn: ${returnDate}%0AName: ${name}%0APhone: ${userPhone}%0ANote: ${note}`;
    const url = `https://wa.me/${phone}?text=${message}`;
    window.open(url, '_blank');
}
